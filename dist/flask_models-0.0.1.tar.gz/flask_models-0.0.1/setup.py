from setuptools import find_packages, setup

setup(
    name='flask_models',
    packages=find_packages(include=["flask_models", "flask_models/database"]),
    version='0.0.2',
    description='Basics models for Python-Flask',
    author='Brixt18',
    license='MIT',
    install_requires=['flask', "flask-login", "flask-sqlalchemy", ],
)